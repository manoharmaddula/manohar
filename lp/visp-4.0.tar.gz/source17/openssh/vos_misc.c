/*  +++begin copyright+++ *******************************  */
/*                                                         */
/*  STRATUS CONFIDENTIAL INFORMATION                       */
/*  COPYRIGHT (c) 2017 Stratus Technologies Bermuda Ltd.   */
/*  All Rights Reserved.                                   */
/*                                                         */
/*  This  program  contains  confidential and proprietary  */
/*  information of Stratus Technologies Bermuda Ltd., and  */
/*  any reproduction, disclosure, or use in whole  or  in  */
/*  part  is  expressly  prohibited,  except  as  may  be  */
/*  specifically authorized by prior written agreement or  */
/*  permission of Stratus.                                 */
/*                                                         */
/*  +++end copyright+++ *********************************  */

#include "vos_misc.h"

static ACL *
get_acl (const char_varying *path, int type, ACL **aclpp, short *codep)
{
     ACL  *path_acl = *aclpp;
     short     code = 0;
     short     max = 4;

     for(;;)
     {
          if (!path_acl)
          {
               size_t s = sizeof(ACL) + sizeof(ACL_ENTRY)*max;

               path_acl = xmalloc(s);
               path_acl->max_entries = max;
               path_acl->num_entries = 0;
          }

          if (type == CHECK_DEFAULT_ACL)
          {
               s$get_default_access_list( path, &path_acl->max_entries,
                                          &path_acl->num_entries, 
                                          path_acl->entries, &code);
          }
          else
          {
               s$get_access_list( path, &path_acl->max_entries,
                                  &path_acl->num_entries, 
                                  path_acl->entries, &code);
          }

          if (code != e$too_many_entries)
          {
               *codep = code;
               *aclpp = path_acl;
               char path_str[MAX_PATH+1];

               strncpy_nstr_vstr (path_str, path, MAX_PATH);
               path_str[MAX_PATH] = '\0';
               debug3("secure_filename: ACL for '%s'", path_str);

               if (!code && path_acl)
               {
                    int k;
                    for (k = 0; k < path_acl->num_entries; k++)
                    {
                         char name[66];

                         strncpy_nstr_vstr(name, &(path_acl->entries[k].user_name), 65);
                         name[65] = '\0';
                         debug3("secure_filename: %c for %s",
                                path_acl->entries[k].access_code, name);
                    }
               }

               return path_acl;
          }

          max = path_acl->num_entries;
          free(path_acl);
          path_acl = NULL;
     }
}

static int 
check_acls(const char *path, const char *pw_name, int type,
           char *indexstr, ACL  *p_master_acl, ACL **p_aclpp)
{
     ACL  *path_acl = NULL;
     int  j, k;
     int  namelen;
     path_cv path_out;
     short code;
     char write_access_code;

     strncpy_vstr_nstr(&path_out, path, MAX_PATH);
     indexstr[0] = '\0';

     path_acl = get_acl (&path_out, type, p_aclpp, &code);
     if (code)
          goto error_return;

     if (path_acl->num_entries <= 0)
     {
          /* No ACL at all means a directory can't be accessed by
             anybody; so, it's kind of useless.
             For a file, no ACL just means the default ACL must
             be checked.  */

          if (type == CHECK_FILE)
               code = -2;
          else
               code = -1;

          goto error_return;
     }

     if (type == CHECK_DIR)
          write_access_code = 'm';
     else
          write_access_code = 'w';

     namelen = strnlen(pw_name, 65);

     debug3("secure_filename: User name = %s, len = %d", pw_name, namelen);
                                  
     /* Loop through all the ACL entries.  */

     for (j = 0; j < path_acl->num_entries; j++)
     {
          char user_name[66];

          char access_code = path_acl->entries[j].access_code;

          /* If this isn't modify or write, we don't
             care about it.  */

          if (access_code != write_access_code)
               continue;

          /* Get a copy of the user name we can substring. */
          strncpy_nstr_vstr (user_name, &(path_acl->entries[j].user_name), 65);
          user_name[65] = '\0';

          /* Any ACL entry beginning with the user name followed by a '.'
             is OK.  */

          if ( memcmp(pw_name, user_name, namelen) == 0
            && user_name[namelen] == '.' )
               continue;

          /* The only other good modify/write entries are those in the
             ACL for the master disk.  */

          for (k = 0; k < p_master_acl->num_entries; k++)
          {
               char master_access_code = p_master_acl->entries[k].access_code;

               /* Only look at modify/write entries.  */
               if (master_access_code != 'm')
                    continue;

               /* If the names match, stop looking.  */
               if (!strcmp_nstr_vstr(user_name, 
                                   &(p_master_acl->entries[k].user_name)))
                    break;
          }

          /* This is not a good ACL entry.  */

          if (k >= p_master_acl->num_entries)
          {
               snprintf(indexstr, MAX_INDEXSTR, " (entry %d)", j+1);
               debug3("secure_filename: Failed Entry = %d", j);
               code = -1;
               goto error_return;
          }
     }

     code = 0;

error_return:
     return code;
}

/*
 * Check a given directory for security. The Unix definition is all components
 * of the path to the file must be owned by either the owner of
 * of the file or root and no directories must be group or world writable.
 * The VOS equivalent of this is going to ensure that any modify/write ACL 
 * entries for the path and it's parent directories either begin with the 
 * user name from the passwd structure OR appear on the master disk.
 *
 * Takes an optional open file descriptor, the file name, the stat structure
 * for the file, the user home dir, the user name, and an error buffer
 * (plus max buffer size) as arguments.
 *
 * Returns 0 on success and -1 on failure
 */

int
auth_secure_path(const char *name, struct stat *stp, const char *pw_dir,
     const char *pw_name, char *err, size_t errlen)
{
     ACL  *master_acl = NULL;
     ACL  *path_acl = NULL;
     disk_cv master_disk;
     char buf[MAX_PATH+1], homedir[MAX_PATH+1];
     char indexstr[MAX_INDEXSTR];
     int comparehome = 0;
     int j;
     int ret = -1;
     module_cv module_name;
     path_cv expanded_path;
     path_cv path_out;
     short type;
     short code;

/* execution */

     strncpy_vstr_nstr(&module_name, "", 0);
     s$get_master_disk(&module_name, &master_disk, &code);
     if (code)
     {
          snprintf(err, errlen, "Master disk:  %s", strerror(code));
          goto error_return;
     }

     get_acl (&master_disk, CHECK_DIR, &master_acl, &code);
     if (code)
     {
          strcpy_nstr_vstr(buf, &master_disk);
          snprintf(err, errlen, "%s:  %s", buf, strerror(code));
          goto error_return;
     }

     /* perform the same steps as realpath(name) but leave the
        final pathname in VOS form.  */

     s$c_expand_path (&name, &expanded_path, &code);
     if (code)
     {
          snprintf(err, errlen, "%s:  %s", name, strerror(code));
          goto error_return;
     }

     s$where_path (&expanded_path, &path_out, &type, &module_name,
          &code);
     if (code)
     {
          strcpy_nstr_vstr(buf, &expanded_path);
          snprintf(err, errlen, "%s:  %s", buf, strerror(code));
          goto error_return;
     }

     strcpy_nstr_vstr(buf, &path_out);

     /* perform the same steps as realpath(pw_dir) but leave the
        final pathname in VOS form.  */

     if (pw_dir != NULL)
     {
          s$c_expand_path (&pw_dir, &expanded_path, &code);
          if (!code)
          {
               s$where_path (&expanded_path, &path_out, &type,
                    &module_name, &code);
               if (!code)
               {
                    strcpy_nstr_vstr(homedir, &path_out);
                    comparehome = 1;
               }
          }
     }
     
     if (!S_ISREG(stp->st_mode))
     {
          snprintf(err, errlen, "%s is not a regular file", buf);
          return -1;
     }

     if ( (code = check_acls(buf, pw_name, CHECK_FILE, indexstr,
                    master_acl, &path_acl)) 
       && code != -2)
     {
          if (code > 0)
               snprintf(err, errlen, "ACL%s for %s:  %s", 
                        indexstr, buf, strerror(code));
          else
               snprintf(err, errlen,
                   "Bad ACL%s for file %s", indexstr, buf);
          goto error_return;
     }

     /* for each component of the canonical path, walking upwards */
     for (j = strlen(buf); j > 0; j--)
     {
          if (buf[j] != '>')
               continue;

          buf[j] = '\0';

          if (code == -2)
          {
               if ((code = check_acls(buf, pw_name, CHECK_DEFAULT_ACL,
                         indexstr, master_acl, &path_acl)))
               {
                    if (code > 0)
                         snprintf(err, errlen, "Default ACL for %s:  %s", 
                                  buf, strerror(code));
                    else
                         snprintf(err, errlen, 
                                  "Bad default ACL%s for directory %s", 
                                  indexstr, buf);
                    goto error_return;
               }
          }

          if ((code = check_acls(buf, pw_name, CHECK_DIR, indexstr,
                         master_acl, &path_acl)))
          {
               if (code > 0)
                    snprintf(err, errlen, "ACL for %s:  %s", 
                             buf, strerror(code));
               else
                    snprintf(err, errlen, "Bad ACL%s for directory %s", 
                             indexstr, buf);
               goto error_return;
          }

          /* If past the homedir then we can stop */
          if (comparehome && strcmp(homedir, buf) == 0) 
               break;
     }

     ret = 0;

error_return:
     if (master_acl)
          free(master_acl);

     if (path_acl)
          free(path_acl);

     return ret;
}
