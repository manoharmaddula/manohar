/* BEGIN INCLUDE FILE ... vos.h */

/* Beginning of modification history */
/* Modified 04-09-27 by Paul Green to fix ssl-85. */
/* Modified 08-08-08 by Paul Green for Releases 1.1 and 2.1. (ssl-297) */
/* Modified 13-06-11 by Miguel Suarez for Release 3.0 (ssl-428). */
/* End of modification history */

/* Define standard data types */

#ifdef    __VOS__

#define   __VOS_EXTENDED_PASSWD
#define   __VOS_EXTENDED_SPWD
#define   setusercontext           vos_setusercontext
#define   login_getclass           vos_login_getclass
#define   login_getcapbool         vos_login_getcapbool
#define   login_getcapstr          vos_login_getcapstr

#define initgroups(name,gid) 0
#define chroot(path) chroot_wrap(path)

#define HAVE_LOGIN_CAP 1

#endif /* __VOS__ */

/* END INCLUDE FILE ... vos.h */
